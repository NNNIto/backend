// src/Foodstagram.Application/Stories/GetStoryDetail/StoryDetailResult.cs
using System;

namespace Foodstagram.Application.Stories.GetStoryDetail;

/// <summary>
/// �X�g�[���[�ڍ׉�ʂɕK�v�ȏ��B
/// </summary>
public sealed record StoryDetailResult(
	long Id,
	long UserId,
	string UserName,
	string AvatarUrl,
	string MediaUrl,
	string MediaType,          // "image", "video" �Ȃ�
	bool IsViewed,
	DateTimeOffset CreatedAt,
	DateTimeOffset ExpiresAt
);
